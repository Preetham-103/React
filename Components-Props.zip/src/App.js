import logo from "./logo.svg";
import "./App.css";
import Greeting from "./component/Greeting";

function App() {
  return (
    <div className="App">
      <section id="core-concepts">
        <Greeting name="Preetham" />
        <Greeting name="Sharath" />
        <Greeting name="Teja" />
      </section>
    </div>
  );
}

export default App;
