import { useEffect, useState } from "react";
// import Button from "./StyleWrapper";
import StyleWrapper from "./StyleWrapper";

export default function Counter() {
  const [count, setCount] = useState(0);
   
  useEffect(() =>{
    // The code that we want to run
    const timestamp = new Date().toLocaleTimeString();
    console.log(`[${timestamp}] Count updated to: ${count}`);
  },[count]); // The dependency array


  return (
    <div>
      <h1 style={{color:"white"}}>Count: {count}</h1>
      <StyleWrapper>
        <button onClick={() => setCount(count + 1)}>Increment</button>
        <button onClick={() => setCount(count - 1)}>Decrement</button>
        <div><button onClick={() => setCount(0)}>Clear</button></div>
      </StyleWrapper>
    </div>
  );
}
